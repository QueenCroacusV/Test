function setup() {createCanvas(400, 400); background(50); stroke('white'); strokeWeight(10);
// Top-left.
point(20, 30);
// Top-left2.
point(100, 100);
// Top-right.
point(200, 70);
// Top-right2.
point(300, 20);
// Base-left.
point(100, 300);
// Base-left2.
point(200, 370);
// Base-right.    
point(300, 250);
// Base-right2.
point(370, 200); 
// Cross1.
point(30, 250);
// Cross2.
point(250, 250); 
  strokeWeight ('2')
line(20, 30, 100, 300);
line(100, 300, 200, 370);
line(200, 370, 300, 250);
line(300, 250, 370, 200);
line(370, 200, 200, 70);
line(370, 200, 300, 20);
// Cross.
line(30, 250, 100, 100);
// Cross2.
line(100, 100, 250, 250);
  strokeWeight ('6')         
// Top-left.
point(300, 200);
// Base-left1.
point(250, 370);
// Base-left2.
point(70, 250);
// Base-right.
point(20, 300);
  strokeWeight ('4') 
point(300, 100);
point(30, 370);  
point(200, 300);
point(70, 20); 
point(30, 100);               
point(370, 30);}