function setup() {createCanvas(400, 400);  frameRate(45); 
background(225, 225, 225); strokeWeight(2); colorMode(RGB, 255); frameRate(45);}

function mouseMoved()
{//makes weird ellipses follow ur mouse, with the color values and stretch factor changing with the position.
let color = mouseY - mouseX * radians(PI/2);
fill(color, 123, 123);
stroke(pow(pmouseY, 1), pow(pmouseX, 1), color)
ellipse(pmouseX, pmouseY, mouseX, mouseY);}

//makes a weird circle in the middle of the screen; the colors correspond with the current hues stated in the above code.
function mouseDragged()
{let circle = pmouseY + pmouseX;
let circleShrink = mouseY + mouseX;
ellipse(200, 200, circle, circle);
ellipse(200, 200, circleShrink/2, circleShrink/2);}