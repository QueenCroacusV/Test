let img; let font;

function preload() {img = loadImage('classroom.jpg'); font = loadFont(TimesNewRoman);
}


function setup() {createCanvas(400, 400); textSize(42);
}

function draw() {background(220); text('good vibes', 50, 50); image(img, 0, 0, mouseX*1.5, mouseY*1.5);
}